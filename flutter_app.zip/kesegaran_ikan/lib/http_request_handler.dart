import 'dart:convert';

import 'package:http/http.dart' as http;

class KlasifikasiJenisAPI
{
  String url;
  String jenis;

  KlasifikasiJenisAPI({this.url, this.jenis});

  factory KlasifikasiJenisAPI.createGetResult(Map<String, dynamic> obj)
  {
    return KlasifikasiJenisAPI(
      url: obj['url'],
      jenis: obj['jenis'],
    );
  }

  static Future<KlasifikasiJenisAPI> connectAPI(String flaskURL, String linktoimage) async
  {
    String apiURL = flaskURL + "jenis/" + linktoimage.split('?')[0];

    var apiResult = await http.get(apiURL);

    var jsonObj = json.decode(apiResult.body);

    return KlasifikasiJenisAPI.createGetResult(jsonObj);

  }

}

class KesegaranMataAPI
{
  String url;
  String jenis;
  String kesegaran_mata;

  KesegaranMataAPI({this.url, this.jenis, this.kesegaran_mata});

  factory KesegaranMataAPI.createGetResult(Map<String, dynamic> obj)
  {
    return KesegaranMataAPI(
      url: obj['url'],
      jenis: obj['jenis'],
      kesegaran_mata: obj['kesegaran_mata'],
    );
  }

  static Future<KesegaranMataAPI> connectAPI2(String flaskURL, String linktoimage) async
  {
    String apiURL = flaskURL + "mata/" + linktoimage.split('?')[0];

    var apiResult = await http.get(apiURL);

    var jsonObj = json.decode(apiResult.body);

    return KesegaranMataAPI.createGetResult(jsonObj);

  }

}

class KesegaranInsangAPI
{
  String url;
  String jenis;
  String kesegaran_insang;

  KesegaranInsangAPI({this.url, this.jenis, this.kesegaran_insang});

  factory KesegaranInsangAPI.createGetResult(Map<String, dynamic> obj)
  {
    return KesegaranInsangAPI(
      url: obj['url'],
      jenis: obj['jenis'],
      kesegaran_insang: obj['kesegaran_insang'],
    );
  }

  static Future<KesegaranInsangAPI> connectAPI3(String flaskURL, String linktoimage) async
  {
    String apiURL = flaskURL + "insang/" + linktoimage.split('?')[0];

    var apiResult = await http.get(apiURL);

    var jsonObj = json.decode(apiResult.body);

    return KesegaranInsangAPI.createGetResult(jsonObj);

  }

}

class SetJenisAPI
{
  String status;
  String jenis;

  SetJenisAPI({this.status, this.jenis});

  factory SetJenisAPI.createGetResult(Map<String, dynamic> obj)
  {
    return SetJenisAPI(
      status: obj['status'],
      jenis: obj['jenis'],
    );
  }

  static Future<SetJenisAPI> connectAPISetJenis(String flaskURL, String jenis) async
  {
    String apiURL = flaskURL + "setjenis/" + jenis;

    var apiResult = await http.get(apiURL);

    var jsonObj = json.decode(apiResult.body);

    return SetJenisAPI.createGetResult(jsonObj);

  }

}