import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_restart/flutter_restart.dart';
import 'global_variable.dart' as globals;
import 'package:flutter_phoenix/flutter_phoenix.dart';
class Kesimpulan extends StatefulWidget {
  @override
  _KesimpulanState createState() => _KesimpulanState();
}

class _KesimpulanState extends State<Kesimpulan> {

  Container titleText(String title){
    return Container(
      margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
      child: Column(
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Container kesimpulanText(String title){
    return Container(
      margin: EdgeInsets.all(16.0),
      child: Column(
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  String hitungKesegaran() {
    var nilai1 = 0;
    var nilai2 = 0;

    var hitungKesegaranMata = globals.kesegaranMata.toString().toLowerCase().split(' ')[0].replaceAll('_', ' ');
    var hitungKesegaranInsang = globals.kesegaranInsang.toString().toLowerCase().split(' ')[0].replaceAll('_', ' ');

    if(hitungKesegaranMata == 'segar'){
      nilai1 = 2;
    }

    else if(hitungKesegaranMata == 'cukup segar'){
      nilai1 = 1;
    }

    else if(hitungKesegaranMata == 'tidak segar'){
      nilai1 = 0;
    }

    if(hitungKesegaranInsang == 'segar'){
      nilai2 = 2;
    }

    else if(hitungKesegaranInsang == 'cukup segar'){
      nilai2 = 1;
    }

    else if(hitungKesegaranInsang == 'tidak segar'){
      nilai2 = 0;
    }

    var total;
    total = ((nilai1 + nilai2) / 4) * 100;

    return total.toString() + "%";

  }

  String cekLayakBeli() {

    var beli = 'jangan';

    var tentukanBeliKesegaranMata = globals.kesegaranMata.toString().toLowerCase().split(' ')[0].replaceAll('_', ' ');
    var tentukanBeliKesegaranInsang = globals.kesegaranInsang.toString().toLowerCase().split(' ')[0].replaceAll('_', ' ');

    // yang sama
    if(tentukanBeliKesegaranMata == 'segar' && tentukanBeliKesegaranInsang == 'segar'){
      beli = 'boleh';
    }
    else if(tentukanBeliKesegaranMata == 'cukup segar' && tentukanBeliKesegaranInsang == 'cukup segar'){
      beli = 'boleh';
    }
    else if(tentukanBeliKesegaranMata == 'tidak segar' && tentukanBeliKesegaranInsang == 'tidak segar'){
      beli = 'jangan';
    }

    // cukup & segar dan sebaliknya
    else if(globals.kesegaranMata.toString().toLowerCase() == 'segar' && tentukanBeliKesegaranInsang == 'cukup segar'){
      beli = 'boleh';
    }
    else if(globals.kesegaranMata.toString().toLowerCase() == 'cukup segar' && tentukanBeliKesegaranInsang == 'segar'){
      beli = 'boleh';
    }

    // yg ada tidak segar
    else if(tentukanBeliKesegaranMata == 'tidak segar' && tentukanBeliKesegaranInsang == 'segar'){
      beli = 'jangan';
    }
    else if(tentukanBeliKesegaranMata == 'tidak segar' && tentukanBeliKesegaranInsang == 'cukup segar'){
      beli = 'jangan';
    }

    else if(tentukanBeliKesegaranMata == 'segar' && tentukanBeliKesegaranInsang == 'tidak segar'){
      beli = 'jangan';
    }
    else if(tentukanBeliKesegaranMata == 'cukup segar' && tentukanBeliKesegaranInsang == 'tidak segar'){
      beli = 'jangan';
    }

    return 'Ikan ' + beli + ' dibeli';
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kesimpulan'),
      ),
      body: ListView(
        children: <Widget>[
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                titleText('Kesimpulan'),
                
                kesimpulanText('Jenis Ikan : ' + globals.jenisIkan.toString().split(' ')[0].replaceAll('_', ' ')),
                kesimpulanText('Mata : ' + globals.kesegaranMata.toString().split(' ')[0].replaceAll('_', ' ')),
                kesimpulanText('Insang : ' + globals.kesegaranInsang.toString().split(' ')[0].replaceAll('_', ' ')),
                kesimpulanText('Tingkat Kesegaran : ' + hitungKesegaran()),
                kesimpulanText(cekLayakBeli()),

                RaisedButton(
                  color: Colors.deepPurpleAccent,
                  child: Text(
                    'Home',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  onPressed: () async{
                    globals.jenisIkan = '';
                    globals.kesegaranMata = '';
                    globals.kesegaranInsang = '';
                    final result = await FlutterRestart.restartApp();
                    print("Result : $result");
                  },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
