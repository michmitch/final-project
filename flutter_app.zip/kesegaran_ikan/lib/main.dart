import 'dart:io';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kesegaran_ikan/deteksi_kesegaran_mata.dart';
import 'package:path/path.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'http_request_handler.dart';
import 'global_variable.dart' as globals;

void main() {
  runApp(
      MyApp()
  );
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Klasifikasi Jenis',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: MyHomePage(title: 'Klasifikasi Jenis'),
    );
  }
}

File _image;
String _filename;

var url = '';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  bool loadingVisible = false;
  bool btnNextVisible = false;
  bool btnVisible = true;
  bool btnKonfirmasiVisible = false;
  bool dropdownVisible = false;
  String txtProcess = '';
  String jenisDropdownValue = 'bandeng';

  TextEditingController controllerLink = new TextEditingController();

  Future _getImage(ImageSource source) async{

    if(klasifikasiJenis != null){
      klasifikasiJenis.jenis = "";
      btnNextVisible = false;
    }

    final _picker = ImagePicker();
    var selectedImage = await _picker.getImage(source: source);

    setState((){
      _image = File(selectedImage.path);
      _filename = basename(_image.path);
    });

    print("Filename : $_filename");
  }

  KlasifikasiJenisAPI klasifikasiJenis;
  SetJenisAPI setJenis;

  Future<void> setJenisConnect() async{
    SetJenisAPI.connectAPISetJenis(controllerLink.text.toString(),
        jenisDropdownValue
    ).then((value){
      setJenis = value;
      globals.jenisIkan = setJenis.jenis.toString();
      globals.serverURL = controllerLink.text.toString();
      setState(() {});
      print(globals.jenisIkan);

    });

  }

  Future<void> testApi() async{

    print(controllerLink.text.toString());
    KlasifikasiJenisAPI.connectAPI(controllerLink.text.toString(),
        url.toString()
    ).then((value){
      klasifikasiJenis = value;
      globals.jenisIkan = klasifikasiJenis.jenis.toString();
      globals.serverURL = controllerLink.text.toString();
      setState(() {});
      print(globals.jenisIkan);

    });
//    await Future.delayed(Duration(seconds: 2));
    setState(() {
      txtProcess = 'Processing Selesai';
    });
    await Future.delayed(Duration(seconds: 2));
  }

  Future<String> uploadAndTestAPI() async{

    setState(() {
      loadingVisible = true;
    });

    StorageReference ref = FirebaseStorage.instance.ref().child(_filename);
    StorageUploadTask uploadTask = ref.putFile(_image);
    uploadTask.events.listen((event){
      setState(() {
        txtProcess = 'Uploading...' + ((event.snapshot.bytesTransferred.toDouble() / event.snapshot.totalByteCount.toDouble()) * 100).toStringAsFixed(2) + '%';
        print(txtProcess);
      });
    });
    var downUrl = await (await uploadTask.onComplete).ref.getDownloadURL();
    url = downUrl.toString();

    print('Download URL : $url');


    if(uploadTask.isComplete){
      txtProcess = 'Upload Selesai';
      await Future.delayed(Duration(seconds: 3));
      setState(() {
        txtProcess = 'Processing...';
      });

      testApi().then((onValue){
        setState(() {
          btnKonfirmasiVisible = true;
          loadingVisible = false;
          btnVisible = false;
        });
      });
    }
  }

  Container titleText(String title){
    return Container(
      margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
      child: Column(
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Container _buildPetunjuk(){
    return Container(
      margin: EdgeInsets.only(top: 16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Text(
            'Masukkan Gambar Tubuh Ikan Seperti',
            style: TextStyle(
                fontSize: 18
            ),
          ),

          FlatButton(
            padding: EdgeInsets.all(0),
            onPressed: (){
              showDialog(
                barrierDismissible: true,
                context: this.context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('Contoh Gambar', textAlign: TextAlign.center,),
                    content:  Container(
                      margin: EdgeInsets.only(bottom: 16.0),
                      width: 300,
                      height: 300,
                      color: Colors.grey[200],
                      child: Container(
                        height: 300,
                        width: 300,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(
                                  'images/bandeng.jpg'
                              ),
                              fit: BoxFit.contain
                          ),
                        ),
                      ) ,
                    ),
                    actions: <Widget>[
                      FlatButton(
                        child: Text("OK"),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );

            },
            child: Text(
              'Ini',
              style: TextStyle(
                  color: Colors.blue[400],
                  fontSize: 18
              ),
            ),
          )
        ],
      ),
    );
  }

  Container _buildTextField(String label, TextEditingController control) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: control,
            decoration: InputDecoration(
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.deepPurple,
                ),
              ),
              labelText: label,
              labelStyle: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container imageContainer(){
    return Container(
      margin: EdgeInsets.only(bottom: 16.0),
      width: 300,
      height: 300,
      color: Colors.grey[200],
      child: _image == null ? SizedBox() : Container(
        height: 300,
        width: 300,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: FileImage(
                  _image
              ),
              fit: BoxFit.contain
          ),
        ),
      ) ,
    );
  }

  Container buttonPilihan(String btnName1, String btnName2, ImageSource source1, ImageSource source2){
    return Container(
      margin: EdgeInsets.only(top: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          RaisedButton(
              child: Text(
                btnName1,
                style: TextStyle(color: Colors.white),
              ),
              color: Colors.deepPurpleAccent,
              onPressed: (){
                _getImage(source1);
              }),
          Text(
            '   Atau   ',
            style: TextStyle(
                fontSize: 16,
                color: Colors.black
            ),
          ),
          RaisedButton(
              child: Text(
                btnName2,
                style: TextStyle(color: Colors.white),
              ),
              color: Colors.deepPurpleAccent,
              onPressed: (){
                _getImage(source2);
              }),
        ],
      ),
    );
  }

  Container buttonUpload(){
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
      child: RaisedButton(
        onPressed: (){
          uploadAndTestAPI();
        },
        color: Color.fromRGBO(76, 178, 178, 1.0),
        child: Text(
          'Upload',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  Container buttonNext(){
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 32),
      child: RaisedButton(
        onPressed: (){
          setJenisConnect().then((onValue){
            Navigator.pushReplacement(this.context, MaterialPageRoute(
              builder: (context){
                _image = null;
//                klasifikasiJenis = null;
                return KesegaranMata();
              },
            ));
          });

        },
        color: Colors.deepPurpleAccent,
        child: Text(
          'Next',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  Column loadingIndicator(){
    return Column(
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(bottom: 16),
          child: CircularProgressIndicator(),
        ),
        Text(
          txtProcess,
          style: TextStyle(
            fontSize: 20,
            color: Colors.black,
          ),
        )
      ],
    );
  }

  Center hasilKlasifikasi(){
    return Center(
      child: Text(
        (klasifikasiJenis != null) ? globals.jenisIkan.toString() : ' ',
        style: TextStyle(
            color: Colors.black,
            fontSize: 20
        ),
      ),
    );
  }

  Container buttonKonfirmasi(){
    return Container(
      child: Column(
        children: <Widget>[
          Text(
            'Apakah Jenisnya Benar?',
            style: TextStyle(
              color: Colors.black,
              fontSize: 20
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RaisedButton(
                  child: Text(
                    'Ya',
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Colors.deepPurpleAccent,
                  onPressed: (){
                    Navigator.push(this.context, MaterialPageRoute(
                      builder: (context){
                        _image = null;
//                klasifikasiJenis = null;
                        return KesegaranMata();
                      },
                    ));
                  }),
              Text(
                '  ',
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.black
                ),
              ),
              RaisedButton(
                  child: Text(
                    'Tidak',
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Colors.deepPurpleAccent,
                  onPressed: (){
                    setState(() {
                      dropdownVisible = true;
                      btnNextVisible = true;
                    });
                  }),
            ],
          ),
        ],
      )
    );
  }

  Container dropdownJenis(){
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Apa Yang Benar? ',
            style: TextStyle(
              color: Colors.black,
              fontSize: 20
            ),
          ),
          DropdownButton<String>(
            value: jenisDropdownValue,
            style: TextStyle(
                color: Colors.black,
                fontSize: 20
            ),

            items: <String>[
              'bandeng',
              'gurame',
              'kerapu',
              'nila',
            ].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            hint: Text(
              'pilih jenis',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
            onChanged: (String value) {
              setState(() {
                jenisDropdownValue = value;
                print(jenisDropdownValue);
              });
            },
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: ListView(
        children: <Widget>[
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                titleText('Klasifikasi Jenis Ikan'),
                _buildPetunjuk(),
                _buildTextField('Server URL', controllerLink),
                imageContainer(),

                Visibility(
                  visible: loadingVisible,
                  child: loadingIndicator(),
                ),
                hasilKlasifikasi(),
                Visibility(
                  visible: (klasifikasiJenis != null)? true: false,
                  child: Column(
                    children: <Widget>[
                      Visibility(
                        visible: dropdownVisible,
                        child: dropdownJenis(),
                      ),
                      buttonKonfirmasi(),
                    ],
                  ),
                ),
                Visibility(
                  visible: btnVisible,
                  child: Column(
                    children: <Widget>[
                      buttonPilihan('Pilih Foto', 'Buka Camera', ImageSource.gallery, ImageSource.camera),
                      Visibility(
                        visible: _image == null ? false : true,
                        child: buttonUpload(),
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: btnNextVisible,
                  child: buttonNext(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}



