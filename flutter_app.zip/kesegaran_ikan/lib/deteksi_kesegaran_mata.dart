import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:kesegaran_ikan/deteksi_kesegaran_insang.dart';
import 'dart:io';
import 'package:path/path.dart';
import 'http_request_handler.dart';
import 'global_variable.dart' as globals;


class KesegaranMata extends StatefulWidget {
  @override
  _KesegaranMataState createState() => _KesegaranMataState();
}

class _KesegaranMataState extends State<KesegaranMata> {

  bool loadingVisible = false;
  bool btnNextVisible = false;
  bool btnVisible = true;
  String txtProcess = '';

  File _image;
  String _filename;

  var url = '';

  KesegaranMataAPI kesegaranMata;

  Future<void> testApi() async{

    KesegaranMataAPI.connectAPI2(globals.serverURL,
        url.toString()
    ).then((value){
      kesegaranMata = value;
      globals.kesegaranMata = kesegaranMata.kesegaran_mata.toString();
      setState(() {});
      print(globals.kesegaranMata);

    });
//    await Future.delayed(Duration(seconds: 5));
    setState(() {
      txtProcess = 'Processing Selesai';
    });
    await Future.delayed(Duration(seconds: 2));
  }

  Future<String> uploadAndTestAPI() async{

    setState(() {
      loadingVisible = true;
    });

    StorageReference ref = FirebaseStorage.instance.ref().child(_filename);
    StorageUploadTask uploadTask = ref.putFile(_image);
    uploadTask.events.listen((event){
      setState(() {
        txtProcess = 'Uploading...' + ((event.snapshot.bytesTransferred.toDouble() / event.snapshot.totalByteCount.toDouble()) * 100).toStringAsFixed(2) + '%';
        print(txtProcess);
      });
    });
    var downUrl = await (await uploadTask.onComplete).ref.getDownloadURL();
    url = downUrl.toString();

    print('Download URL : $url');


    if(uploadTask.isComplete){
      txtProcess = 'Upload Selesai';
      await Future.delayed(Duration(seconds: 3));
      setState(() {
        txtProcess = 'Processing...';
      });

      testApi().then((onValue){
        setState(() {
          btnNextVisible = true;
          loadingVisible = false;
          btnVisible = false;
        });
      });
    }
  }

  Future _getImage(ImageSource source) async{

    if(kesegaranMata != null){
      kesegaranMata.kesegaran_mata = "";
      btnNextVisible = false;
    }

    final _picker = ImagePicker();
    var selectedImage = await _picker.getImage(source: source);

    setState((){
      _image = File(selectedImage.path);
      _filename = basename(_image.path);
    });

    print("Filename : $_filename");
  }

  Container titleText(String title){
    return Container(
      margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
      child: Column(
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Container _buildPetunjuk(){
    return Container(
      margin: EdgeInsets.only(top: 16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Text(
            'Masukkan Gambar Mata Ikan Seperti',
            style: TextStyle(
                fontSize: 18
            ),
          ),

          FlatButton(
            padding: EdgeInsets.all(0),
            onPressed: (){
              showDialog(
                barrierDismissible: true,
                context: this.context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('Contoh Gambar', textAlign: TextAlign.center,),
                    content:  Container(
                      margin: EdgeInsets.only(bottom: 16.0),
                      width: 300,
                      height: 300,
                      color: Colors.grey[200],
                      child: Container(
                        height: 300,
                        width: 300,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(
                                  'images/bandeng_mata.jpg'
                              ),
                              fit: BoxFit.contain
                          ),
                        ),
                      ) ,
                    ),
                    actions: <Widget>[
                      FlatButton(
                        child: Text("OK"),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );

            },
            child: Text(
              'Ini',
              style: TextStyle(
                  color: Colors.blue[400],
                  fontSize: 18
              ),
            ),
          )
        ],
      ),
    );
  }

  Container imageContainer(){
    return Container(
      margin: EdgeInsets.only(bottom: 16.0),
      width: 300,
      height: 300,
      color: Colors.grey[200],
      child: _image == null ? SizedBox() : Container(
        height: 300,
        width: 300,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: FileImage(
                  _image
              ),
              fit: BoxFit.contain
          ),
        ),
      ) ,
    );
  }

  Container buttonPilihan(String btnName1, String btnName2, ImageSource source1, ImageSource source2){
    return Container(
      margin: EdgeInsets.only(top: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          RaisedButton(
              child: Text(
                btnName1,
                style: TextStyle(color: Colors.white),
              ),
              color: Colors.deepPurpleAccent,
              onPressed: (){
                _getImage(source1);
              }),
          Text(
            '   Atau   ',
            style: TextStyle(
                fontSize: 16,
                color: Colors.black
            ),
          ),
          RaisedButton(
              child: Text(
                btnName2,
                style: TextStyle(color: Colors.white),
              ),
              color: Colors.deepPurpleAccent,
              onPressed: (){
                _getImage(source2);
              }),
        ],
      ),
    );
  }

  Container buttonUpload(){
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
      child: RaisedButton(
        onPressed: (){
          uploadAndTestAPI();
        },
        color: Color.fromRGBO(76, 178, 178, 1.0),
        child: Text(
          'Upload',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  Container buttonNext(){
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 32),
      child: RaisedButton(
        onPressed: (){
          Navigator.pushReplacement(this.context, MaterialPageRoute(
            builder: (context){
              _image = null;
              return KesegaranInsang();
            },
          ));
        },
        color: Colors.deepPurpleAccent,
        child: Text(
          'Next',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  Column loadingIndicator(){
    return Column(
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(bottom: 16),
          child: CircularProgressIndicator(),
        ),
        Text(
          txtProcess,
          style: TextStyle(
            fontSize: 20,
            color: Colors.black,
          ),
        )
      ],
    );
  }

  Center hasilKesegaranMata(){
    return Center(
      child: Text(
        (kesegaranMata != null) ? globals.kesegaranMata.toString() : ' ',
        style: TextStyle(
            color: Colors.black,
            fontSize: 20
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kesegaran Mata'),
      ),
      body: ListView(
        children: <Widget>[
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                titleText('Kesegaran Mata'),
                _buildPetunjuk(),
                imageContainer(),
                Visibility(
                  visible: loadingVisible,
                  child: loadingIndicator(),
                ),
                hasilKesegaranMata(),
                Visibility(
                  visible: btnVisible,
                  child: Column(
                    children: <Widget>[
                      buttonPilihan('Pilih Foto', 'Buka Camera', ImageSource.gallery, ImageSource.camera),
                      Visibility(
                        visible: _image == null ? false : true,
                        child: buttonUpload(),
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: btnNextVisible,
                  child: buttonNext(),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
