library myprj_globals;

String jenisIkan = " ";
String kesegaranMata = " ";
String kesegaranInsang = " ";

String serverURL = "no data";